package com.service;

import com.DAO.AssociateMgmtDAO;
import com.bean.Associate;

public class AssociateMgmtService {

	AssociateMgmtDAO dao = new AssociateMgmtDAO();

	public Associate getAssociate(long associateId) {
		return dao.getAssociate(associateId);
	}
	
	public boolean deleteAssociate(long associateId) {
		return dao.deleteAssociate(associateId);
	}
}
