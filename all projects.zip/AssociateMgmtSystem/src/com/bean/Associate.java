package com.bean;

public class Associate {

	long associateId;
	String associateName;
	double salary;
	String designation;
	long phoneNo;

	public Associate() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Associate(long associateId, String associateName, double salary, String designation, long phoneNo) {
		super();
		this.associateId = associateId;
		this.associateName = associateName;
		this.salary = salary;
		this.designation = designation;
		this.phoneNo = phoneNo;
	}

	public long getAssociateId() {
		return associateId;
	}

	public void setAssociateId(long associateId) {
		this.associateId = associateId;
	}

	public String getAssociateName() {
		return associateName;
	}

	public void setAssociateName(String associateName) {
		this.associateName = associateName;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public long getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}

}
