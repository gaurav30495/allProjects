package com.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bean.Associate;
import com.service.AssociateMgmtService;

@WebServlet("/AssociateMgmtServlet")
public class AssociateMgmtServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public AssociateMgmtServlet() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getParameter("action");
		RequestDispatcher rd = null;
		AssociateMgmtService ams = new AssociateMgmtService();

		if (action.equals("show")) {
			long associateId = Long.parseLong(request.getParameter("associateId"));

			Associate associate = ams.getAssociate(associateId);
			if (associate != null) {
				rd = request.getRequestDispatcher("show.jsp");
				request.setAttribute("associate", associate);
				rd.forward(request, response);
			} else {
				rd = request.getRequestDispatcher("error.jsp");
				rd.forward(request, response);
			}
		}
		else if (action.equals("delete")){
			long associateId = Long.parseLong(request.getParameter("associateId"));
			boolean present= ams.deleteAssociate(associateId);
			if(present==true) {
				rd = request.getRequestDispatcher("delete.jsp");
				request.setAttribute("associateId", associateId);
				rd.forward(request, response);
			}
			
			
		}

		{

		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
