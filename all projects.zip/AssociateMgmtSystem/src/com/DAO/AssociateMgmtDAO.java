package com.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.bean.Associate;
import com.util.DatabaseUtil;

public class AssociateMgmtDAO {

	public Associate getAssociate(long associateId) {
		Associate associate = null;
		Connection con = DatabaseUtil.getConnection();

		try {
			PreparedStatement getAssociate = con
					.prepareStatement("select * from Associate_1426650 where associateId=?");
			getAssociate.setLong(1, associateId);

			ResultSet rs = getAssociate.executeQuery();

			while (rs.next()) {
				associate = new Associate(rs.getLong("associateId"), rs.getString("associateName"),
						rs.getDouble("salary"), rs.getString("designation"), rs.getLong("phoneNo"));
			}
			DatabaseUtil.closeResultSet(rs);
			DatabaseUtil.closePreparedStatement(getAssociate);
			DatabaseUtil.closeConnection(con);

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return associate;
	}

	public boolean deleteAssociate(long associateId) {
		boolean deleted = false;

		Connection con = DatabaseUtil.getConnection();

		try {
			PreparedStatement pst = con.prepareStatement("delete from Associate_1426650 where associateId=?");
			pst.setLong(1, associateId);

			int t = pst.executeUpdate();

			if (t > 0) {
				deleted = true;
			}

			DatabaseUtil.closePreparedStatement(pst);
			DatabaseUtil.closeConnection(con);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return deleted;
	}
}
