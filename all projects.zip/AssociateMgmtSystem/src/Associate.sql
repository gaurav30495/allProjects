create table Associate_1426650(
associateId number(8) primary key,
associateName varchar2(50) not null,
salary number(10,3) not null,
designation varchar2(50) not null,
phoneNo number(10) not null
)

insert into Associate_1426650 values (123,'Gaurav',25000,'ASE',9106089569)
insert into Associate_1426650 values (456,'Rahul',52000,'SE',8764357128);
insert into Associate_1426650 values (789,'Nisarg',60000,'SE',7043183257);

select * from Associate_1426650

