create table Employee123(
employeeId varchar2(10) primary key,
employeeName varchar2(50) not null,
location varchar2(15) not null,
designation varchar2(10) not null,
salary number(7) not null
)

insert into Employee123 values('1','Rajat','tvm','ase', 50000)

select * from Employee123

update Employee123 set salary = salary + ? where employeeId=?