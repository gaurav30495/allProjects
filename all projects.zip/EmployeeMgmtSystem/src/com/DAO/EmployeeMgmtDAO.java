package com.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.bean.Employee;
import com.util.DatabaseUtil;

public class EmployeeMgmtDAO {

	public boolean addEmployee(Employee e) {
		boolean added = true;
		boolean ainvayi = false;

		Connection con = DatabaseUtil.getConnection();
		try {
			PreparedStatement ps = con.prepareStatement("select * from Employee123");

			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				if (e.getEmployeeId().equals(rs.getString(1))) {
					added = false;
					break;
				}
			}

				if (added == true) {
					PreparedStatement addEmployee = con.prepareStatement("insert into Employee123 values(?,?,?,?,?)");
					addEmployee.setString(1, e.getEmployeeId());
					addEmployee.setString(2, e.getEmployeeName());
					addEmployee.setString(3, e.getLocation());
					addEmployee.setString(4, e.getDesignation());
					addEmployee.setDouble(5, e.getSalary());

					int t = addEmployee.executeUpdate();
					if (t > 0) {
						ainvayi = true;
					}
				
			
					DatabaseUtil.closePreparedStatement(addEmployee);

				}
				DatabaseUtil.closeResultSet(rs);
				DatabaseUtil.closePreparedStatement(ps);
				DatabaseUtil.closeConnection(con);
			
		} catch (SQLException e1) {
			System.out.println(e1.getMessage());
		}
		return ainvayi;
	}

	public ArrayList<Employee> getAllEmployees() {

		ArrayList<Employee> empList = new ArrayList<>();

		Connection con = DatabaseUtil.getConnection();
		try {
			PreparedStatement getEmployees = con.prepareStatement("select * from Employee123");

			ResultSet allEmp = getEmployees.executeQuery();

			while (allEmp.next()) {
				Employee e = new Employee(allEmp.getString("employeeId"), allEmp.getString("employeeName"),
						allEmp.getString("location"), allEmp.getString("designation"), allEmp.getInt("salary"));

				empList.add(e);
			}
			DatabaseUtil.closeResultSet(allEmp);
			DatabaseUtil.closePreparedStatement(getEmployees);
			DatabaseUtil.closeConnection(con);

		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		return empList;
	}

	public boolean depositSalary(String empId, int amount) {
		boolean deposited = false;

		Connection con = DatabaseUtil.getConnection();
		try {
			PreparedStatement ps = con
					.prepareStatement("update Employee123 set salary = salary + ? where employeeId=?");
			ps.setInt(1, amount);
			ps.setString(2, empId);

			int t = ps.executeUpdate();

			if (t > 0) {
				deposited = true;
			}
			DatabaseUtil.closePreparedStatement(ps);
			DatabaseUtil.closeConnection(con);
		} catch (SQLException e1) {
			e1.printStackTrace();
		}

		return deposited;
	}
}
