package com.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bean.Employee;
import com.service.EmployeeMgmtService;

@WebServlet("/EmployeeMgmtServlet")
public class EmployeeMgmtServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public EmployeeMgmtServlet() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		EmployeeMgmtService ems = new EmployeeMgmtService();
		String action = request.getParameter("action");
		RequestDispatcher rd = null;

		if (action.equals("ADD")) {
			String empId = request.getParameter("employeeId");
			String empName = request.getParameter("employeeName");
			String location = request.getParameter("location");
			String designation = request.getParameter("designation");
			int salary = Integer.parseInt(request.getParameter("salary"));

			Employee e = new Employee(empId, empName, location, designation, salary);
			boolean added = ems.addEmployee(e);
			if (added==false) {
				rd = request.getRequestDispatcher("failure.jsp");
				rd.forward(request, response);
			} else {
				
				rd = request.getRequestDispatcher("success.jsp");
				request.setAttribute("employee", e);
				rd.forward(request, response);
			}
			System.out.println(added);
		} else if (action.equals("list")) {
			ArrayList<Employee> empList = null;
			empList = ems.getAllEmployees();
			request.setAttribute("employeeList", empList);
			rd = request.getRequestDispatcher("list.jsp");
			rd.forward(request, response);
		} else if (action.equals("deposit")) {
			String empId = request.getParameter("empId");
			int amount = Integer.parseInt(request.getParameter("salary"));

			boolean deposited = ems.depositSalary(empId, amount);
			if (deposited) {
				request.setAttribute("employeeList", ems.getAllEmployees());
				rd = request.getRequestDispatcher("list.jsp");
				rd.forward(request, response);
			}
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
