package com.service;

import java.util.ArrayList;

import com.DAO.EmployeeMgmtDAO;
import com.bean.Employee;

public class EmployeeMgmtService {

	EmployeeMgmtDAO dao = new EmployeeMgmtDAO();

	public boolean addEmployee(Employee e) {
		return dao.addEmployee(e);
	}

	public ArrayList<Employee> getAllEmployees() {
		return dao.getAllEmployees();
	}

	public boolean depositSalary(String empId, int amount) {
		return dao.depositSalary(empId, amount);

	}
}
