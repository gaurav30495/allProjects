create table books_1426650(

bookId number(7) primary key,
bookName varchar2(25),
publisher varchar2(25),
status varchar2(10),
issueTo varchar2(25)
)

insert into books_1426650 values (110001,'Medical Dictionary','James Co','Available',' ');
insert into books_1426650 values (110002,'Rosie Pierce','Prince Publishers','Issued', 'Sanjay');
insert into books_1426650 values (110003,'xyz','abc Publishers','Issued', 'Sanjay');
insert into books_1426650 values (110004,'dddddd','gaurav','Issued','hmmm');
insert into books_1426650 values (110005,'Dictionary','hunm','Available',' ');



select * from books_1426650

select count(*) from books_1426650 where issueTo='Sanjay'

update books_1426650 set issueTo = 'Sanjay' where bookId = '110001'

update books_1426650 set status = 'issued' where bookId = ?