package com.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.bean.Book;
import com.util.DatabaseUtil;

public class LibMgmtDAO {

	public ArrayList<Book> getAllBook() {

		ArrayList<Book> allBook = new ArrayList<>();

		Connection con = DatabaseUtil.getConnection();

		try {
			PreparedStatement getAllBook = con.prepareStatement("select * from books_1426650");

			ResultSet eachBook = getAllBook.executeQuery();

			while (eachBook.next()) {
				Book book = new Book(eachBook.getLong("bookId"), eachBook.getString("bookName"),
						eachBook.getString("publisher"), eachBook.getString("status"), eachBook.getString("issueTo"));
				allBook.add(book);
			}

			DatabaseUtil.closePreparedStatement(getAllBook);
			DatabaseUtil.closeConnection(con);

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return allBook;
	}

	public int whetherIssuedTo(String name) {
		int issued = 0;

		Connection con = DatabaseUtil.getConnection();
		try {
			PreparedStatement pst = con.prepareStatement("select count(*) from books_1426650 where issueTo=?");
			pst.setString(1, name);

			ResultSet rs = pst.executeQuery();

			while (rs.next()) {
				issued = rs.getInt(1);
			}

			DatabaseUtil.closeResultSet(rs);
			DatabaseUtil.closePreparedStatement(pst);
			DatabaseUtil.closeConnection(con);

		} catch (SQLException e) {
			e.getStackTrace();
		}
		System.out.println(issued);
		return issued;

	}

	public boolean updateName(String issuedTo, long bookId) {
		boolean update = false;

		Connection con = DatabaseUtil.getConnection();

		try {
			PreparedStatement pst1 = con.prepareStatement("update books_1426650 set issueTo = ?,status = 'issued'  where bookId = ?");
			pst1.setString(1, issuedTo);
			pst1.setLong(2, bookId);

			int t1 = pst1.executeUpdate();

			if (t1 > 0) {
					update = true;
				}
			DatabaseUtil.closePreparedStatement(pst1);
			DatabaseUtil.closeConnection(con);

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return update;
	}
	
	public boolean returnBook (long bookId) {
		boolean returned = false;
	
		Connection con = DatabaseUtil.getConnection();

		try {
			PreparedStatement pst1 = con.prepareStatement("update books_1426650 set issueTo = ' ',status = 'Available' where bookId = ?");
			pst1.setLong(1, bookId);

			int t1 = pst1.executeUpdate();

			if (t1 > 0) {
					returned = true;
				}
			DatabaseUtil.closePreparedStatement(pst1);
			DatabaseUtil.closeConnection(con);

		} catch (SQLException e) {
			e.printStackTrace();
		}
	
	return returned;
	}

}
