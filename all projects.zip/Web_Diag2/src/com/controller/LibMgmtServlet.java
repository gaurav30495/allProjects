package com.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bean.Book;
import com.service.LibMgmtService;

@WebServlet("/LibMgmtServlet")
public class LibMgmtServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public LibMgmtServlet() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String action = request.getParameter("action");
		RequestDispatcher rd = null;
		LibMgmtService lms = new LibMgmtService();

		if (action.equals("view")) {
			ArrayList<Book> allBooks;
			allBooks = lms.getAllBook();
			rd = request.getRequestDispatcher("view.jsp");
			request.setAttribute("allBooks", allBooks);
			rd.forward(request, response);
		}

		else if (action.equals("issue")) {
			String name = request.getParameter("issuedTo");
			int issued = lms.whetherIssuedTo(name);

			if (issued < 3) {

				String issuedTo = request.getParameter("issuedTo");
				long bookId = Long.parseLong(request.getParameter("bookId"));
				lms.updateName(issuedTo, bookId);
				rd = request.getRequestDispatcher("issueSuccess.jsp");
				rd.forward(request, response);
			} else {
				response.sendRedirect("issueError.jsp");
			}
		} else if (action.equals("return")) {
			long bookId = Long.parseLong(request.getParameter("bookId"));
			lms.returnBook(bookId);
			rd = request.getRequestDispatcher("index.jsp");
			rd.forward(request, response);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
