package com.service;

import java.util.ArrayList;

import com.DAO.LibMgmtDAO;
import com.bean.Book;

public class LibMgmtService {

	LibMgmtDAO dao = new LibMgmtDAO();

	public ArrayList<Book> getAllBook() {
		return dao.getAllBook();
	}
	public int whetherIssuedTo(String name) {
		return dao.whetherIssuedTo(name);
	}
	public boolean updateName(String issuedTo, long bookId) {
		return dao.updateName(issuedTo, bookId);
	}
	public boolean returnBook (long bookId) {
		return dao.returnBook(bookId);
	}
}
