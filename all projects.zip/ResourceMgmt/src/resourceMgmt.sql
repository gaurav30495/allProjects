create table associate(
associateId varchar2(5) primary key,
associateName varchar2(25) not null,
baseBranch varchar2(25) not null,
experience number(4,2) not null
)

create table manager(
managerId varchar2(5),
managerName varchar2(25) not null,
location Varchar2(25) not null
)
