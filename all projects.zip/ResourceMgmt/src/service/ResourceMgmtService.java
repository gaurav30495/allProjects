package service;

import java.sql.SQLException;

import DAO.ResourceMgmtDAO;
import bean.Associate;
import bean.Manager;

public class ResourceMgmtService {

	ResourceMgmtDAO dao = new ResourceMgmtDAO();

	public boolean AddManagerAndAssociate(Associate a, Manager m) throws SQLException {
		return dao.AddManagerAndAssociate(a, m);
	}
}
