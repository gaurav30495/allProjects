package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import Util.DataBaseUtil;
import bean.Associate;
import bean.Manager;

public class ResourceMgmtDAO {

	public boolean AddManagerAndAssociate(Associate a, Manager m) throws SQLException {
		boolean added = false;

		Connection con = DataBaseUtil.getConnection();
		PreparedStatement AddManager = con.prepareStatement("insert into manager values(?,?,?)");
		AddManager.setString(1, m.getManagerId());
		AddManager.setString(2, m.getManagerName());
		AddManager.setString(3, m.getLocation());

		PreparedStatement AddAssociate = con.prepareStatement("insert into associate values(?,?,?,?)");
		AddAssociate.setString(1, a.getAssociateId());
		AddAssociate.setString(2, a.getAssociateName());
		AddAssociate.setString(3, a.getBaseBranch());
		AddAssociate.setDouble(4, a.getExperience());

		int x = AddManager.executeUpdate();

		if (x > 0) {
			int t = AddAssociate.executeUpdate();
			if (t > 0) {
				added = true;
			}
		}
		DataBaseUtil.closePreparedStatement(AddAssociate);
		DataBaseUtil.closePreparedStatement(AddManager);
		DataBaseUtil.closeConnection(con);
		return added;
	}

}
