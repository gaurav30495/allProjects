package bean;

public class Manager {
	String managerId;
	String managerName;
	String location;

	Associate associate;

	public Manager() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Manager(String managerId, String managerName, String location) {
		super();
		this.managerId = managerId;
		this.managerName = managerName;
		this.location = location;
	}

	public String getManagerId() {
		return managerId;
	}

	public void setManagerId(String managerId) {
		this.managerId = managerId;
	}

	public String getManagerName() {
		return managerName;
	}

	public void setManagerName(String managerName) {
		this.managerName = managerName;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Associate getAssociate() {
		return associate;
	}

	public void setAssociate(Associate associate) {
		this.associate = associate;
	}

}
