package bean;

public class Associate {
String associateId;
String associateName;
String baseBranch;
double experience;
public Associate() {
	super();
	// TODO Auto-generated constructor stub
}
public Associate(String associateId, String associateName, String baseBranch, double experience) {
	super();
	this.associateId = associateId;
	this.associateName = associateName;
	this.baseBranch = baseBranch;
	this.experience = experience;
}
public String getAssociateId() {
	return associateId;
}
public void setAssociateId(String associateId) {
	this.associateId = associateId;
}
public String getAssociateName() {
	return associateName;
}
public void setAssociateName(String associateName) {
	this.associateName = associateName;
}
public String getBaseBranch() {
	return baseBranch;
}
public void setBaseBranch(String baseBranch) {
	this.baseBranch = baseBranch;
}
public double getExperience() {
	return experience;
}
public void setExperience(double experience) {
	this.experience = experience;
}


}
