package servlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Associate;
import bean.Manager;
import service.ResourceMgmtService;

@WebServlet("/ResourceMgmtServlet")
public class ResourceMgmtServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public ResourceMgmtServlet() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		ResourceMgmtService rms = new ResourceMgmtService();
		RequestDispatcher rd = null;
		
		String action = request.getParameter("action");
		if(action.equals("ADD")) {
		String managerId = request.getParameter("managerId");
		String managerName = request.getParameter("managerName");
		String location = request.getParameter("location");
		String associateId = request.getParameter("associateId");
		String associateName = request.getParameter("associateName");
		String baseBranch = request.getParameter("baseBranch");
		double experience = Double.parseDouble(request.getParameter("experience"));
		Associate a = new Associate(associateId, associateName, baseBranch, experience);
		Manager m = new Manager(managerId, managerName, location);
		try {
			boolean added = rms.AddManagerAndAssociate(a, m);
			if(added == true) {
				request.setAttribute("ManageId", managerId);
				request.setAttribute("AssociateId", associateId);
				rd = request.getRequestDispatcher("success.jsp");
				rd.forward(request, response);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
	}

}
