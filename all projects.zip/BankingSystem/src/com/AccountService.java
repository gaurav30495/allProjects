package com;

import java.util.ArrayList;

public class AccountService {
	public ArrayList<Account> getAllAccount() {
		AccountDao dao=new AccountDao();
		return dao.getAllAccount();
	}
	
	public boolean deleteAccount(String accNo) {
		AccountDao dao=new AccountDao();
		return dao.deleteAccount(accNo);
	}
	
	public boolean deposit(String accNo, double amount) {
		AccountDao dao=new AccountDao();
		return dao.deposit(accNo, amount);
	}
}
