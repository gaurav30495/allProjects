package com;

public class Account {
	String accNo;
	String name;
	String type;
	double balance;
	String branch;
	public String getAccNo() {
		return accNo;
	}
	public void setAccNo(String accNo) {
		this.accNo = accNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public Account(String accNo, String name, String type, double balance, String branch) {
		super();
		this.accNo = accNo;
		this.name = name;
		this.type = type;
		this.balance = balance;
		this.branch = branch;
	}
	public Account() {
		super();
	}
	@Override
	public String toString() {
		return "Account [accNo=" + accNo + ", name=" + name + ", type=" + type + ", balance=" + balance + ", branch="
				+ branch + "]";
	}
	
}
