package com;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AccountServlet
 */
@WebServlet("/AccountServlet")
public class AccountServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public AccountServlet() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action=request.getParameter("action");
		RequestDispatcher rd=null;
		AccountService service=new AccountService();
		if(action.equals("List")) {
			ArrayList<Account> acctList=service.getAllAccount();
			rd=request.getRequestDispatcher("list.jsp");
			request.setAttribute("accList", acctList);
			rd.forward(request, response);
		} else if(action.equals("Delete")) {
			String accNo=request.getParameter("accNo");
			boolean t=service.deleteAccount(accNo);
			ArrayList<Account> acctList=service.getAllAccount();
			rd=request.getRequestDispatcher("list.jsp");
			request.setAttribute("accList", acctList);
			rd.forward(request, response);
		} else if(action.equals("Deposit")) {
			String accNo=request.getParameter("accNo");
			String amount=request.getParameter("amount");
			double amt=Double.parseDouble(amount);
			boolean t=service.deposit(accNo, amt);
			ArrayList<Account> acctList=service.getAllAccount();
			rd=request.getRequestDispatcher("list.jsp");
			request.setAttribute("accList", acctList);
			rd.forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
