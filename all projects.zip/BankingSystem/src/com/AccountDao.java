package com;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class AccountDao {
	public ArrayList<Account> getAllAccount() {
		ArrayList<Account> accountList=new ArrayList<Account>();
		try{
			Connection cn=DatabaseUtil.getConnection();
			PreparedStatement ps=cn.prepareStatement("SELECT * FROM ACCOUNT_928535");
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				Account a=new Account(rs.getString(1),rs.getString(2),rs.getString(3),rs.getDouble(4),rs.getString(5));
				accountList.add(a);
			}
			DatabaseUtil.closeResultSet(rs);
			DatabaseUtil.closePreparedStatement(ps);
			DatabaseUtil.closeConnection(cn);
		} catch(SQLException e) {
			System.out.println(e.getMessage());
		}
		return accountList;
	}
	
	public boolean deleteAccount(String accNo) {
		boolean result=false;
		try{
			Connection cn=DatabaseUtil.getConnection();
			PreparedStatement ps=cn.prepareStatement("DELETE FROM ACCOUNT_928535 WHERE ACC_NO=?");
			ps.setString(1, accNo);
			int t=ps.executeUpdate();
			if(t>0) {
				result=true;
			}
			DatabaseUtil.closePreparedStatement(ps);
			DatabaseUtil.closeConnection(cn);
		} catch(SQLException e) {
			System.out.println(e.getMessage());
		}
		return result;
	}
	
	public boolean deposit(String accNo, double amount) {
		boolean result=false;
		try{
			Connection cn=DatabaseUtil.getConnection();
			PreparedStatement ps=cn.prepareStatement("UPDATE ACCOUNT_928535 SET AVAIL_BALANCE=AVAIL_BALANCE+? WHERE ACC_NO=?");
			ps.setDouble(1, amount);
			ps.setString(2, accNo);
			int t=ps.executeUpdate();
			if(t>0) {
				result=true;
			}
			DatabaseUtil.closePreparedStatement(ps);
			DatabaseUtil.closeConnection(cn);
		} catch(SQLException e) {
			System.out.println(e.getMessage());
		}
		return result;
	}
}
