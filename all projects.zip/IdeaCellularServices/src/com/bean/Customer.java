package com.bean;

import java.util.ArrayList;

public class Customer {
	
	private long customerId;
	private String customerName;
	
	ArrayList<Connections> connectionList;

	public Customer(long customerId, String customerName, ArrayList<Connections> connectionList) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.connectionList = connectionList;
	}

	public Customer() {
		super();
	}

	public long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public ArrayList<Connections> getConnectionList() {
		return connectionList;
	}

	public void setConnectionList(ArrayList<Connections> connectionList) {
		this.connectionList = connectionList;
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", connectionList="
				+ connectionList + "]";
	}
	
	
	
	
}
