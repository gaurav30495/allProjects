package com.bean;

public class Connections {
	
	
	private long connectionId;
	private String connectionPlan;
	private String connectionType;
	public long getConnectionId() {
		return connectionId;
	}
	public void setConnectionId(long connectionId) {
		this.connectionId = connectionId;
	}
	public String getConnectionPlan() {
		return connectionPlan;
	}
	public void setConnectionPlan(String connectionPlan) {
		this.connectionPlan = connectionPlan;
	}
	public String getConnectionType() {
		return connectionType;
	}
	public void setConnectionType(String connectionType) {
		this.connectionType = connectionType;
	}
	public Connections(long connectionId, String connectionPlan, String connectionType) {
		super();
		this.connectionId = connectionId;
		this.connectionPlan = connectionPlan;
		this.connectionType = connectionType;
	}
	public Connections() {
		super();
	}
	@Override
	public String toString() {
		return "Connections [connectionId=" + connectionId + ", connectionPlan=" + connectionPlan + ", connectionType="
				+ connectionType + "]";
	}
	
	
	
}
