package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.bean.Connections;
import com.util.DatabaseUtil;

public class DatabaseDao {
	
	public static ArrayList<Long> dropDown() { 
		
		ArrayList<Long> dropDownList = new ArrayList<>();
		
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try { 
			
			con = DatabaseUtil.getConnection();
			ps = con.prepareStatement("SELECT CUSTOMERID FROM CUSTOMER_1647075");
			rs = ps.executeQuery();
			while(rs.next()) { 
				
				dropDownList.add(rs.getLong("CUSTOMERID"));
			}
			
			
		}
		catch(SQLException e) { 
			System.out.println(e.getMessage());
		}
		
		return dropDownList;
	}
	
	public static ArrayList<Connections> viewConnections(long CustomerId) {
		ArrayList<Connections> connectionList = new ArrayList<>();
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try { 
			
			con = DatabaseUtil.getConnection();
			ps = con.prepareStatement("SELECT * FROM CONNECTION_1647075 WHERE CUSTOMERID=?");
			ps.setLong(1, CustomerId);
			rs = ps.executeQuery();
			while(rs.next()) { 
				Connections connection = new Connections(rs.getLong(1), rs.getString(2), rs.getString(3));
				connectionList.add(connection);
			}
			
			
		}
		catch(SQLException e) { 
			System.out.println(e.getMessage());
		}
		
		
		
		return connectionList;		
	}
	
	
}
