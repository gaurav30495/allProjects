package com.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bean.Connections;
import com.service.Service;



/**
 * Servlet implementation class ControllerServlet
 */
@WebServlet("/ControllerServlet")
public class ControllerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ControllerServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String action = request.getParameter("action");
		if(action.equalsIgnoreCase("list")) { 
			ArrayList<Long> dropDownTempList = Service.dropDown();
			request.setAttribute("dropDownList",dropDownTempList );
			request.getRequestDispatcher("ViewConnections.jsp").forward(request, response);
		}
		else if(action.equalsIgnoreCase("show")){ 
			long custId = Long.parseLong(request.getParameter("customerId"));
			ArrayList<Connections> connectionList = Service.viewConnections(custId);
			ArrayList<Long> dropDownTempList = Service.dropDown();
			request.setAttribute("dropDownList",dropDownTempList );
			request.setAttribute("connectionsList",connectionList);
			request.getRequestDispatcher("ViewConnections.jsp").forward(request, response);	
		}
	}

}
