package com.service;

import java.util.ArrayList;

import com.bean.Connections;
import com.dao.DatabaseDao;

public class Service {
	
	public static ArrayList<Long> dropDown() { 
		return DatabaseDao.dropDown();
	}
	
	public static ArrayList<Connections> viewConnections(long CustomerId){
		return DatabaseDao.viewConnections(CustomerId);
	}
	
}
