create table account123(
accountNo varchar2(11),
accountHolderName varchar2(50),
accountType varchar2(10),
balance number(6)
)

select * from ACCOUNT123