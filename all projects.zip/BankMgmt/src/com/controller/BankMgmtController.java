package com.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.activity.ActivityRequiredException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.catalina.connector.Request;

import com.bean.account;
import com.service.BankMgmtService;

@WebServlet("/BankMgmtController")
public class BankMgmtController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public BankMgmtController() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getParameter("action");
		RequestDispatcher rd = null;
		BankMgmtService bms = new BankMgmtService();

		if (action.equals("view")) {
			ArrayList<account> accList = null;
			try {
				accList = bms.getAllAccounts();
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
			request.setAttribute("accList", accList);
			rd = request.getRequestDispatcher("showList.jsp");
			rd.forward(request, response);
		}
		else if(action.equals("Delete")) {
			String accno = request.getParameter("accNo");
			try {
				boolean deleted = bms.deleteAccount(accno);
				if(deleted==true) {
					rd = request.getRequestDispatcher("showList.jsp");
					request.setAttribute("accList", bms.getAllAccounts());
					rd.forward(request, response);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String action = request.getParameter("action");
		RequestDispatcher rd = null;
		BankMgmtService bms = new BankMgmtService();

		if (action.equals("ADD")) {
			String accountNo = request.getParameter("accountNo");
			String accountHolderName = request.getParameter("name");
			String accountType = request.getParameter("accountType");
			double balance = Double.parseDouble(request.getParameter("balance"));

			account a = new account(accountNo, accountHolderName, accountType, balance);

			try {
				boolean added = bms.addAccount(a);
				if (added == true) {
					request.setAttribute("accountNumber", accountNo);
					rd = request.getRequestDispatcher("success.jsp");
					rd.forward(request, response);
				}

			} catch (SQLException e) {
				System.out.println(e.getMessage());
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
		}

		else if (action.equals("DEPOSIT")) {
			String accountNo = request.getParameter("accountNo");
			double amount = Double.parseDouble(request.getParameter("amount"));
			try {
				boolean deposited = bms.depositAccount(accountNo, amount);
				if (deposited == true) {
					rd = request.getRequestDispatcher("showList.jsp");
					request.setAttribute("accList", bms.getAllAccounts());
					rd.forward(request, response);
				}
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}

		}

	}

}
