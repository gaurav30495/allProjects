package com.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.spi.DirStateFactory.Result;

import com.bean.account;
import com.util.DataBaseUtil;

public class BankMgmtDAO {

	public boolean addAccount(account a) throws SQLException {
		boolean added = false;

		Connection con = DataBaseUtil.getConnection();

		PreparedStatement addAccount = con.prepareStatement("insert into account123 values(?,?,?,?)");
		addAccount.setString(1, a.getAccountNo());
		addAccount.setString(2, a.getAccountHolderName());
		addAccount.setString(3, a.getAccountType());
		addAccount.setDouble(4, a.getBalance());

		int t = addAccount.executeUpdate();

		if (t > 0) {
			added = true;
		}
		return added;
	}

	public ArrayList<account> getAllAccounts() throws SQLException{
		ArrayList<account> accList = new ArrayList<account>();
		
		Connection con = DataBaseUtil.getConnection();
		
		PreparedStatement allAccount = con.prepareStatement("select * from account123");
		
		ResultSet rs = allAccount.executeQuery();
		
		while(rs.next()) {
			
			account a = new account(rs.getString("accountNo"), 
					rs.getString("accountHolderName"), 
					rs.getString("accountType"), 
					rs.getDouble("balance"));
			
			accList.add(a);
		}
		
		DataBaseUtil.closeResultSet(rs);
		DataBaseUtil.closePreparedStatement(allAccount);
		DataBaseUtil.closeConnection(con);
		
		return accList;
	}

	public boolean depositAccount(String accountNo, double amount) throws SQLException {
		boolean deleted = false;
		Connection con = DataBaseUtil.getConnection();
		
		PreparedStatement allAccount = con.prepareStatement("update account123 set balance=balance+? where accountNo=?");
		allAccount.setDouble(1, amount);
		allAccount.setString(2, accountNo);
		int t = allAccount.executeUpdate();
		
		if(t>0) {
			deleted = true;
		}
		DataBaseUtil.closePreparedStatement(allAccount);
		DataBaseUtil.closeConnection(con);
		
		return deleted;
	}
	
	public boolean deleteAccount (String accno) throws SQLException {
		boolean deleted = false;
		Connection con = DataBaseUtil.getConnection();

		PreparedStatement delAccount = con.prepareStatement("delete from account123 where accountNo=?");
		delAccount.setString(1, accno);

		int t = delAccount.executeUpdate();

		if (t > 0) {
			deleted = true;
		}
		DataBaseUtil.closePreparedStatement(delAccount);
		DataBaseUtil.closeConnection(con);
		return deleted;
	}
}

