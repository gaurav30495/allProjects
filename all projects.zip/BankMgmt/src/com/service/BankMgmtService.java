package com.service;

import java.sql.SQLException;
import java.util.ArrayList;

import com.DAO.BankMgmtDAO;
import com.bean.account;

public class BankMgmtService {

	BankMgmtDAO dao = new BankMgmtDAO();
	public boolean addAccount (account a) throws SQLException{
		return dao.addAccount(a);
	}
	
	public ArrayList<account> getAllAccounts() throws SQLException{
		return dao.getAllAccounts();
	}
	
	public boolean depositAccount(String accountNo, double amount) throws SQLException {
		return dao.depositAccount(accountNo, amount);
	}
	
	public boolean deleteAccount (String accno) throws SQLException {
		return dao.deleteAccount(accno);
	}
}
